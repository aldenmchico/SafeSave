let dbConfig = {
    host: 'db',
    user: 'root',
    password: 'DemoDatabasePassword!!123',
    database: 'capstone_2023_securepass1',
    multipleStatements: true
}
export { dbConfig }
