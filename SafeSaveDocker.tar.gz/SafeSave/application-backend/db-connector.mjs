let dbConfig = {
    user: 'root',
    host: 'db',
    password: 'DemoDatabasePassword!!123',
    database: 'capstone_2023_securepass1',
    connectionLimit: 10
}
export { dbConfig }
